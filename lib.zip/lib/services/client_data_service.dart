import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hefestocs/models/client.dart';

class ClientDataService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Carga los datos del cliente desde Firestore
  /// Parámetros:
  ///  - clientId: El ID del documento del cliente
  ///  - docPath: (Opcional) Path directo al documento (coaches/{coachId}/clients/{clientId})
  ///    Si se proporciona, carga directamente el documento, mucho más eficiente
  Future<Client> loadClientData(String clientId, {String? docPath}) async {
    try {
      print('📥 [ClientDataService] Buscando datos del cliente: "$clientId"');

      if (clientId.isEmpty) {
        throw Exception('ClientId está vacío');
      }

      DocumentSnapshot doc;

      // Si tenemos docPath, cargar directamente (mucho más eficiente)
      if (docPath != null && docPath.isNotEmpty) {
        print('⚡ [ClientDataService] Carga directa usando docPath: $docPath');

        try {
          doc = await _firestore.doc(docPath).get();

          if (!doc.exists) {
            print(
                '⚠️ [ClientDataService] Documento no existe en docPath, usando fallback');
            // Si el path directo falla, hacer fallback a collectionGroup
            final querySnapshot =
                await _firestore.collectionGroup('clients').limit(100).get();

            final matchingDocs =
                querySnapshot.docs.where((doc) => doc.id == clientId).toList();

            if (matchingDocs.isEmpty) {
              throw Exception('Cliente no encontrado con ID: $clientId');
            }

            doc = matchingDocs.first;
          } else {
            print('✅ [ClientDataService] Documento cargado directamente');
          }
        } catch (e) {
          print('⚠️ [ClientDataService] Error en carga directa: $e');
          print(
              '🔄 [ClientDataService] Intentando fallback a collectionGroup...');

          // Fallback si hay cualquier error con el path directo
          final querySnapshot =
              await _firestore.collectionGroup('clients').limit(100).get();

          final matchingDocs =
              querySnapshot.docs.where((doc) => doc.id == clientId).toList();

          if (matchingDocs.isEmpty) {
            throw Exception('Cliente no encontrado con ID: $clientId');
          }

          doc = matchingDocs.first;
        }
      } else {
        // Sin docPath - probablemente sesión antigua
        print('⚠️ [ClientDataService] No hay docPath guardado');
        throw Exception(
          'Sesión incompatible. Por favor cierra sesión y vuelve a iniciar con tu código de invitación.',
        );
      }

      final data = doc.data() as Map<String, dynamic>;

      print(
          '✅ [ClientDataService] Cliente encontrado: ${data['fullName'] ?? 'Sin nombre'}');

      // Convertir los datos de Firestore a modelo Client
      final client = Client.fromFirestore(doc.id, data);

      // Imprimir resumen de datos cargados
      print('📊 [ClientDataService] Datos cargados:');
      print('   - Nombre: ${client.fullName}');
      print('   - Antropometrías: ${client.anthropometryHistory.length}');
      print('   - Kcal objetivo: ${client.kcalTarget}');
      print(
          '   - Proteína: ${client.proteinG}g, Grasa: ${client.fatG}g, Carbs: ${client.carbG}g');

      return client;
    } catch (e, stackTrace) {
      print('❌ [ClientDataService] Error al cargar cliente: $e');
      print('Stack trace: $stackTrace');
      rethrow;
    }
  }

  /// Stream en tiempo real de los datos del cliente
  /// Se actualiza automáticamente cuando cambian los datos en Firestore
  Stream<Client> watchClientData(String clientId) {
    print('👀 [ClientDataService] Iniciando stream para cliente: $clientId');

    return _firestore
        .collectionGroup('clients')
        .snapshots()
        .asyncMap((querySnapshot) async {
      try {
        print(
            '🔄 [ClientDataService] Stream actualizado: ${querySnapshot.docs.length} documentos');

        // Filtrar manualmente por ID
        final matchingDocs =
            querySnapshot.docs.where((doc) => doc.id == clientId).toList();

        if (matchingDocs.isEmpty) {
          print(
              '⚠️ [ClientDataService] Cliente no encontrado en stream: $clientId');
          throw Exception('Cliente no encontrado con ID: $clientId');
        }

        final doc = matchingDocs.first;
        final data = doc.data();

        print(
            '✅ [ClientDataService] Stream - Cliente actualizado: ${data['fullName']}');

        return Client.fromFirestore(doc.id, data);
      } catch (e) {
        print('❌ [ClientDataService] Error procesando snapshot: $e');
        rethrow;
      }
    }).handleError((error, stackTrace) {
      print('❌ [ClientDataService] Error en stream: $error');
      print('Stack trace: $stackTrace');
    }, test: (error) => error is Exception);
  }

  /// Obtiene la última medición de antropometría ordenada por fecha
  Map<String, dynamic>? getLatestAnthropometry(Client client) {
    if (client.anthropometryHistory.isEmpty) {
      return null;
    }

    // Ordenar por fecha descendente (más reciente primero)
    final sortedHistory =
        List<Map<String, dynamic>>.from(client.anthropometryHistory)
          ..sort((a, b) {
            final dateA = DateTime.parse(a['date'] as String);
            final dateB = DateTime.parse(b['date'] as String);
            return dateB.compareTo(dateA); // Descendente
          });

    return sortedHistory.first;
  }

  /// Calcula el indicador de déficit/superávit calórico
  /// Retorna:
  ///  - 'deficit' si kcalTarget < TMB estimada
  ///  - 'maintenance' si está cerca de TMB
  ///  - 'surplus' si kcalTarget > TMB estimada
  String getCalorieIndicator({
    required int kcalTarget,
    required double weight,
    String? activityLevel,
  }) {
    // Estimación simple de TMB usando fórmula de Harris-Benedict simplificada
    // TMB base ≈ 10 * peso (kg) + 6.25 * altura - 5 * edad + factor
    // Para simplificar, usamos un promedio: TMB ≈ 24 * peso
    final estimatedTMB = 24 * weight;

    // Factor de actividad (multiplicador de TMB)
    double activityMultiplier = 1.5; // Moderadamente activo por defecto
    if (activityLevel != null) {
      switch (activityLevel.toLowerCase()) {
        case 'sedentario':
        case 'sedentary':
          activityMultiplier = 1.2;
          break;
        case 'ligero':
        case 'light':
          activityMultiplier = 1.375;
          break;
        case 'moderado':
        case 'moderate':
          activityMultiplier = 1.55;
          break;
        case 'activo':
        case 'active':
          activityMultiplier = 1.725;
          break;
        case 'muy activo':
        case 'very active':
          activityMultiplier = 1.9;
          break;
      }
    }

    final estimatedTDEE = estimatedTMB * activityMultiplier;

    // Calcular diferencia
    final difference = kcalTarget - estimatedTDEE;

    if (difference < -200) {
      return 'deficit'; // Déficit calórico
    } else if (difference > 200) {
      return 'surplus'; // Superávit calórico
    } else {
      return 'maintenance'; // Mantenimiento
    }
  }

  /// Actualiza el payload del cliente con merge
  /// Útil para agregar logs de entrenamiento sin sobreescribir otros datos
  Future<void> updatePayload({
    required String docPath,
    required Map<String, dynamic> updates,
  }) async {
    try {
      print('💾 [ClientDataService] Actualizando payload en: $docPath');
      print(
          '📝 [ClientDataService] Datos a actualizar: ${updates.keys.join(", ")}');

      await _firestore.doc(docPath).set(
            updates,
            SetOptions(merge: true),
          );

      print('✅ [ClientDataService] Payload actualizado exitosamente');
    } catch (e, stackTrace) {
      print('❌ [ClientDataService] Error al actualizar payload: $e');
      print('Stack trace: $stackTrace');
      rethrow;
    }
  }

  /// Obtiene el documento completo de Firestore (incluyendo payload)
  Future<Map<String, dynamic>> getFullDocument(String docPath) async {
    try {
      print('📥 [ClientDataService] Obteniendo documento completo: $docPath');

      final doc = await _firestore.doc(docPath).get();

      if (!doc.exists) {
        throw Exception('Documento no encontrado en: $docPath');
      }

      final data = doc.data() as Map<String, dynamic>;
      print('✅ [ClientDataService] Documento completo obtenido');

      return data;
    } catch (e, stackTrace) {
      print('❌ [ClientDataService] Error al obtener documento: $e');
      print('Stack trace: $stackTrace');
      rethrow;
    }
  }
}
